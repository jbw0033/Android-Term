package edu.auburn.eng.csse.comp3170.sjh0020.gradecalculator;


import android.app.FragmentManager;
import android.os.Bundle;

import android.support.v7.app.ActionBarActivity;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;

import java.util.ArrayList;

public class MainActivity extends FragmentActivity implements NewclassFragment.NewclassListener, WeightFragment.WeightFragmentListener, DeleteFragment.DeleteFragmentListener {





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);
        setContentView(R.layout.container);


        if (findViewById(R.id.frag_container) != null)
        {

            if (savedInstanceState != null)
            {
                return;
            }

            // Create an instance of MainFragment
            MainFragment firstFragment = new MainFragment();
            firstFragment.setArguments(getIntent().getExtras());

            // Add the fragment to the 'fragment_container' FrameLayout
            FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
            transaction.add(R.id.frag_container, firstFragment);
            transaction.addToBackStack(null);
            transaction.commit();
        }


    }



    public void addButtonPressed(View v){
        // Create an instance of ExampleFragment
        NewclassFragment newClassFragment = new NewclassFragment();
        newClassFragment.setArguments(getIntent().getExtras());

        // Add the fragment to the 'fragment_container' FrameLayout
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        //transaction.add(R.id.frag_container, newClassFragment);
        transaction.replace(R.id.frag_container, newClassFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void deleteButtonPressed(View v){
        // Create an instance of ExampleFragment
        DeleteFragment deleteFragment = new DeleteFragment();
        deleteFragment.setArguments(getIntent().getExtras());

        // Add the fragment to the 'fragment_container' FrameLayout
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frag_container, deleteFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void goToWeightsPressed(){
        // Create an instance of ExampleFragment
        WeightFragment weightFragment = new WeightFragment();
        weightFragment.setArguments(getIntent().getExtras());

        // Add the fragment to the 'fragment_container' FrameLayout
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        //transaction.add(R.id.frag_container, newClassFragment);
        transaction.replace(R.id.frag_container, weightFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    public void goBackHome(){
        MainFragment firstFragment = new MainFragment();
        firstFragment.setArguments(getIntent().getExtras());

        // Add the fragment to the 'fragment_container' FrameLayout
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.replace(R.id.frag_container, firstFragment);
        transaction.addToBackStack(null);
        transaction.commit();
    }

    /*public void doneButtonPressed(View v){
        // Create an instance of ExampleFragment
        NewclassFragment newClassFragment = new NewclassFragment();
        newClassFragment.setArguments(getIntent().getExtras());

        // Add the fragment to the 'fragment_container' FrameLayout
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        //transaction.add(R.id.frag_container, newClassFragment);
        transaction.replace(R.id.frag_container, newClassFragment);
        transaction.commit();
    }*/
    /*public void onCalculatePressed(View v) {

        System.out.println("calculating Grade");
        double totalGrade = 0.0;

        EditText weightField;
        EditText gradeField;
        double weight = 0.0;
        double grade = 0.0;

        try {
            weightField = (EditText) findViewById(R.id.weight1);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) findViewById((R.id.grade1));
            grade = Double.parseDouble(gradeField.getText().toString());
        } catch (Exception e) {
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        try {
            weightField = (EditText) findViewById(R.id.weight2);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) findViewById((R.id.grade2));
            grade = Double.parseDouble(gradeField.getText().toString());
        } catch (Exception e) {
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        try {
            weightField = (EditText) findViewById(R.id.weight3);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) findViewById((R.id.grade3));
            grade = Double.parseDouble(gradeField.getText().toString());
        } catch (Exception e) {
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        try {
            weightField = (EditText) findViewById(R.id.weight4);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) findViewById((R.id.grade4));
            grade = Double.parseDouble(gradeField.getText().toString());
        } catch (Exception e) {
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;


        try {
            weightField = (EditText) findViewById(R.id.weight5);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) findViewById((R.id.grade5));
            grade = Double.parseDouble(gradeField.getText().toString());
        } catch (Exception e) {
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        TextView totalGradeView;
        totalGradeView = (TextView) findViewById(R.id.finalGrade);
        totalGradeView.setText(Double.toString(totalGrade));
    }*/
}


