package edu.auburn.eng.csse.comp3170.sjh0020.gradecalculator;

import android.support.v4.app.Fragment;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class DeleteFragment extends Fragment
{
    Button deleteButton;
    CheckBox class1;
    CheckBox class2;
    CheckBox class3;
    CheckBox class4;
    CheckBox class5;
    CheckBox class6;
    CheckBox class7;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {


        return inflater.inflate(R.layout.fragment_delete, container, false);
    }

    public interface DeleteFragmentListener {
        public void goBackHome();
    }

    @Override
    public void onStart()
    {
        super.onStart();

        CheckBox class1 = (CheckBox) getView().findViewById(R.id.class_1);
        CheckBox class2 = (CheckBox) getView().findViewById(R.id.class_2);
        CheckBox class3 = (CheckBox) getView().findViewById(R.id.class_3);
        CheckBox class4 = (CheckBox) getView().findViewById(R.id.class_4);
        CheckBox class5 = (CheckBox) getView().findViewById(R.id.class_5);
        CheckBox class6 = (CheckBox) getView().findViewById(R.id.class_6);
        CheckBox class7 = (CheckBox) getView().findViewById(R.id.class_7);


        class1.setVisibility(View.INVISIBLE);
        class2.setVisibility(View.INVISIBLE);
        class3.setVisibility(View.INVISIBLE);
        class4.setVisibility(View.INVISIBLE);
        class5.setVisibility(View.INVISIBLE);
        class6.setVisibility(View.INVISIBLE);
        class7.setVisibility(View.INVISIBLE);


        int numberOfCourses = MainFragment.courses.size();
        switch(numberOfCourses){
            case 7:
                class7.setVisibility(View.VISIBLE);
                class7.setText(MainFragment.courses.get(6).courseName);

            case 6:
                class6.setVisibility(View.VISIBLE);
                class6.setText(MainFragment.courses.get(5).courseName);
            case 5:
                class5.setVisibility(View.VISIBLE);
                class5.setText(MainFragment.courses.get(4).courseName);
            case 4:
                class4.setVisibility(View.VISIBLE);
                class4.setText(MainFragment.courses.get(3).courseName);
            case 3:
                class3.setVisibility(View.VISIBLE);
                class3.setText(MainFragment.courses.get(2).courseName);
            case 2:
                class2.setVisibility(View.VISIBLE);
                class2.setText(MainFragment.courses.get(1).courseName);
            case 1:
                class1.setVisibility(View.VISIBLE);
                class1.setText(MainFragment.courses.get(0).courseName);
            default:
                break;
        }

        deleteButton = (Button) getView().findViewById(R.id.deleteButton);
        deleteButton.setOnClickListener(new Button.OnClickListener() {

        public void onClick(View v) {

            CheckBox class1 = (CheckBox) getView().findViewById(R.id.class_1);
            CheckBox class2 = (CheckBox) getView().findViewById(R.id.class_2);
            CheckBox class3 = (CheckBox) getView().findViewById(R.id.class_3);
            CheckBox class4 = (CheckBox) getView().findViewById(R.id.class_4);
            CheckBox class5 = (CheckBox) getView().findViewById(R.id.class_5);
            CheckBox class6 = (CheckBox) getView().findViewById(R.id.class_6);
            CheckBox class7 = (CheckBox) getView().findViewById(R.id.class_7);

            if(class1.isChecked()){
                for (int i = 0; i < MainFragment.courses.size(); i++) {
                    if (MainFragment.courses.get(i).courseName.equals(class1.getText().toString())) {
                        MainFragment.courses.remove(i);
                        break;
                    }
                }
            }
            if(class2.isChecked()) {
                for (int i = 0; i < MainFragment.courses.size(); i++) {
                    if (MainFragment.courses.get(i).courseName.equals(class2.getText().toString())) {
                        MainFragment.courses.remove(i);

                    }
                }
            }
            if(class3.isChecked()) {
                for (int i = 0; i < MainFragment.courses.size(); i++) {
                    if (MainFragment.courses.get(i).courseName.equals(class3.getText().toString())) {
                        MainFragment.courses.remove(i);

                    }
                }
            }
            if(class4.isChecked()) {
                for (int i = 0; i < MainFragment.courses.size(); i++) {
                    if (MainFragment.courses.get(i).courseName.equals(class4.getText().toString())) {
                        MainFragment.courses.remove(i);

                    }
                }
            }
            if(class5.isChecked()) {
                for (int i = 0; i < MainFragment.courses.size(); i++) {
                    if (MainFragment.courses.get(i).courseName.equals(class5.getText().toString())) {
                        MainFragment.courses.remove(i);

                    }
                }
            }
            if(class6.isChecked()) {
                for (int i = 0; i < MainFragment.courses.size(); i++) {
                    if (MainFragment.courses.get(i).courseName.equals(class6.getText().toString())) {
                        MainFragment.courses.remove(i);

                    }
                }
            }
            if(class7.isChecked()) {
                for (int i = 0; i < MainFragment.courses.size(); i++) {
                    if (MainFragment.courses.get(i).courseName.equals(class7.getText().toString())) {
                        MainFragment.courses.remove(i);

                    }
                }
            }

            DeleteFragmentListener parent = (DeleteFragmentListener) getActivity();
            parent.goBackHome();

        }

        });


                //List all the shit from MainFragment.courses.  This will be like the listing in MainFragment where we set the visibility of a class if it's there, and then set the text to Course.courseName.
                //check the boxes
                //if the box is checked when done is pressed, MainFragment.courses.remove(*index of box that was checked*)
                //goBackToHome();   this will be in the interface just like in the weightFragment

    }
}