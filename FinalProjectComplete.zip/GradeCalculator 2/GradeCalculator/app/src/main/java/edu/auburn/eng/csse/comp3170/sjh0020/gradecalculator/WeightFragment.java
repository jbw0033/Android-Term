package edu.auburn.eng.csse.comp3170.sjh0020.gradecalculator;

import android.support.v4.app.Fragment;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class WeightFragment extends Fragment {

    Button button;

    public interface WeightFragmentListener {
        public void goBackHome();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_weight, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();


        TextView classForWeight1 = (TextView) getView().findViewById(R.id.classForWeight1);
        TextView classForWeight2 = (TextView) getView().findViewById(R.id.classForWeight2);
        TextView classForWeight3 = (TextView) getView().findViewById(R.id.classForWeight3);
        TextView classForWeight4 = (TextView) getView().findViewById(R.id.classForWeight4);
        TextView classForWeight5 = (TextView) getView().findViewById(R.id.classForWeight5);
        EditText percentage1 = (EditText) getView().findViewById(R.id.percentage1);
        EditText percentage2 = (EditText) getView().findViewById(R.id.percentage2);
        EditText percentage3 = (EditText) getView().findViewById(R.id.percentage3);
        EditText percentage4 = (EditText) getView().findViewById(R.id.percentage4);
        EditText percentage5 = (EditText) getView().findViewById(R.id.percentage5);

        int numberOfAssignments = MainFragment.courses.get(MainFragment.courses.size() - 1).catNames.size();
        System.out.println(MainFragment.courses.size());
        if (numberOfAssignments >= 1) {
            classForWeight1.setText(MainFragment.courses.get(MainFragment.courses.size() - 1).catNames.get(0));
            percentage1.setText(".00");
        }
        if (numberOfAssignments >= 2) {
            classForWeight2.setText(MainFragment.courses.get(MainFragment.courses.size() - 1).catNames.get(1));
            percentage2.setText(".00");
        }
        if (numberOfAssignments >= 3) {
            classForWeight3.setText(MainFragment.courses.get(MainFragment.courses.size() - 1).catNames.get(2));
            percentage3.setText(".00");
        }
        if (numberOfAssignments >= 4) {
            classForWeight4.setText(MainFragment.courses.get(MainFragment.courses.size() - 1).catNames.get(3));
            percentage4.setText(".00");
        }
        if (numberOfAssignments >= 5) {
            classForWeight5.setText(MainFragment.courses.get(MainFragment.courses.size() - 1).catNames.get(4));
            percentage5.setText(".00");
        }

        button = (Button) getView().findViewById(R.id.doneButton1);
        button.setOnClickListener(new Button.OnClickListener() {

            public void onClick(View v) {
                EditText percentage1 = (EditText) getView().findViewById(R.id.percentage1);
                EditText percentage2 = (EditText) getView().findViewById(R.id.percentage2);
                EditText percentage3 = (EditText) getView().findViewById(R.id.percentage3);
                EditText percentage4 = (EditText) getView().findViewById(R.id.percentage4);
                EditText percentage5 = (EditText) getView().findViewById(R.id.percentage5);

                EditText editText1 = (EditText) getView().findViewById(R.id.editText);
                EditText editText2 = (EditText) getView().findViewById(R.id.editText2);
                EditText editText3 = (EditText) getView().findViewById(R.id.editText3);
                EditText editText4 = (EditText) getView().findViewById(R.id.editText4);
                EditText editText5 = (EditText) getView().findViewById(R.id.editText5);


                try {
                    MainFragment.courses.get(MainFragment.courses.size() - 1).weights.set(0, Double.parseDouble(percentage1.getText().toString()));
                    MainFragment.courses.get(MainFragment.courses.size() - 1).catScores.set(0, Double.parseDouble(editText1.getText().toString()));
                }catch(Exception e){System.out.println(e.getMessage());}
                try {
                    MainFragment.courses.get(MainFragment.courses.size() - 1).weights.set(1, Double.parseDouble(percentage2.getText().toString()));
                    MainFragment.courses.get(MainFragment.courses.size() - 1).catScores.set(1, Double.parseDouble(editText2.getText().toString()));
                }catch(Exception e){System.out.println("exception caught at 1");}
                try {
                    MainFragment.courses.get(MainFragment.courses.size() - 1).weights.set(2, Double.parseDouble(percentage3.getText().toString()));
                    MainFragment.courses.get(MainFragment.courses.size() - 1).catScores.set(2, Double.parseDouble(editText3.getText().toString()));
                }catch(Exception e){System.out.println("exception caught at 2");}
                try {
                    MainFragment.courses.get(MainFragment.courses.size() - 1).weights.set(3, Double.parseDouble(percentage4.getText().toString()));
                    MainFragment.courses.get(MainFragment.courses.size() - 1).catScores.set(3, Double.parseDouble(editText4.getText().toString()));
                }catch(Exception e){System.out.println("exception caught at 3");}
                try {
                    MainFragment.courses.get(MainFragment.courses.size() - 1).weights.set(4, Double.parseDouble(percentage5.getText().toString()));
                    MainFragment.courses.get(MainFragment.courses.size() - 1).catScores.set(4, Double.parseDouble(editText5.getText().toString()));
                }catch(Exception e){System.out.println("exception caught at 4");}

                int i = 0;
                /*while (i < 5) {
                    try {
                        MainFragment.courses.get(MainFragment.courses.size() - 1).catScores.set(i, 0.0);
                    }catch(Exception e){}
                    i++;
                }*/

                WeightFragmentListener parent = (WeightFragmentListener) getActivity();
                parent.goBackHome();

            }

        });
    }
}