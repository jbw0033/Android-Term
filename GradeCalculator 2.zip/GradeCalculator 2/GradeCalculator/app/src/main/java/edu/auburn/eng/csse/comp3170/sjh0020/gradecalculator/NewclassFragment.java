package edu.auburn.eng.csse.comp3170.sjh0020.gradecalculator;

import android.support.v4.app.Fragment;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.support.v4.app.FragmentActivity;
import android.widget.Toast;

public class NewclassFragment extends Fragment
{
    Button doneButton;
public interface NewclassListener
    {
        public void goToWeightsPressed();
    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {
        return inflater.inflate(R.layout.fragment_newclass, container, false);
    }

    @Override
    public void onStart()
    {
        super.onStart();

        doneButton = (Button) getView().findViewById(R.id.doneButton);
        doneButton.setOnClickListener(new Button.OnClickListener(){

            public void onClick(View v){
                CheckBox examsChecked = (CheckBox)getView().findViewById(R.id.exams_check);
                CheckBox finalChecked = (CheckBox)getView().findViewById(R.id.final_check);
                CheckBox hwChecked = (CheckBox)getView().findViewById(R.id.hw_check);
                CheckBox projectChecked = (CheckBox)getView().findViewById(R.id.project_check);
                CheckBox otherChecked = (CheckBox)getView().findViewById(R.id.other_check);


                if(examsChecked.isChecked()){
                    MainActivity.courses.get(MainActivity.courses.size()-1).catNames.add("Exams");
                    MainActivity.courses.get(MainActivity.courses.size()-1).weights.add(0.0);
                    MainActivity.courses.get(MainActivity.courses.size()-1).catScores.add(0.0);
                }
                if(finalChecked.isChecked()){
                    MainActivity.courses.get(MainActivity.courses.size()-1).catNames.add("Final");
                    MainActivity.courses.get(MainActivity.courses.size()-1).weights.add(0.0);
                    MainActivity.courses.get(MainActivity.courses.size()-1).catScores.add(0.0);
                }
                if(hwChecked.isChecked()){
                    MainActivity.courses.get(MainActivity.courses.size()-1).catNames.add("Homework");
                    MainActivity.courses.get(MainActivity.courses.size()-1).weights.add(0.0);
                    MainActivity.courses.get(MainActivity.courses.size()-1).catScores.add(0.0);
                }
                if(projectChecked.isChecked()){
                    MainActivity.courses.get(MainActivity.courses.size()-1).catNames.add("Project");
                    MainActivity.courses.get(MainActivity.courses.size()-1).weights.add(0.0);
                    MainActivity.courses.get(MainActivity.courses.size()-1).catScores.add(0.0);
                }
                if(otherChecked.isChecked()){
                    MainActivity.courses.get(MainActivity.courses.size()-1).catNames.add("Other");
                    MainActivity.courses.get(MainActivity.courses.size()-1).weights.add(0.0);
                    MainActivity.courses.get(MainActivity.courses.size()-1).catScores.add(0.0);
                }

                NewclassListener parent = (NewclassListener) getActivity();
                parent.goToWeightsPressed();
            }
        });

    }




}