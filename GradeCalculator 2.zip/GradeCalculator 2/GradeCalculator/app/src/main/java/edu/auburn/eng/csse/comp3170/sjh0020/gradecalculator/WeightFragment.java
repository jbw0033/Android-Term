package edu.auburn.eng.csse.comp3170.sjh0020.gradecalculator;

import android.support.v4.app.Fragment;

import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class WeightFragment extends Fragment
{

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState)
    {

        return inflater.inflate(R.layout.fragment_weight, container, false);
    }

    @Override
    public void onStart()
    {
        super.onStart();
        TextView classForWeight1 = (TextView)getView().findViewById(R.id.classForWeight1);
        TextView classForWeight2 = (TextView)getView().findViewById(R.id.classForWeight2);
        TextView classForWeight3 = (TextView)getView().findViewById(R.id.classForWeight3);
        TextView classForWeight4 = (TextView)getView().findViewById(R.id.classForWeight4);
        TextView classForWeight5 = (TextView)getView().findViewById(R.id.classForWeight5);

        int numberOfAssignments = MainActivity.courses.get(MainActivity.courses.size()-1).catNames.size();
        classForWeight1.setText(Integer.toString(numberOfAssignments));
        if(numberOfAssignments >= 1){
            classForWeight1.setText(MainActivity.courses.get(MainActivity.courses.size()-1).catNames.get(0));
        }
        if(numberOfAssignments >= 2){
            classForWeight2.setText(MainActivity.courses.get(MainActivity.courses.size()-1).catNames.get(1));
        }
        if(numberOfAssignments >= 3){
            classForWeight3.setText(MainActivity.courses.get(MainActivity.courses.size()-1).catNames.get(2));
        }
        if(numberOfAssignments >= 4){
            classForWeight4.setText(MainActivity.courses.get(MainActivity.courses.size()-1).catNames.get(3));
        }
        if(numberOfAssignments >= 5){
            classForWeight5.setText(MainActivity.courses.get(MainActivity.courses.size()-1).catNames.get(4));
        }

    }





}