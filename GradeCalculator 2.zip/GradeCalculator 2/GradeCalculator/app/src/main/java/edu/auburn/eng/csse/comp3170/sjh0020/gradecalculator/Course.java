package edu.auburn.eng.csse.comp3170.sjh0020.gradecalculator;

import java.util.ArrayList;

/**
 * Created by Michael on 4/29/2016.
 */
public class Course {
    ArrayList<Double> weights = new ArrayList<Double>();
    ArrayList<String> catNames = new ArrayList<String>();
    ArrayList<Double> catScores = new ArrayList<Double>();

    public double calcGrade(){
        double grade = 0;
        int i = 0;
        while(i < weights.size()){
            grade += weights.get(i) * catScores.get(i);
            i++;
        }
        return i;
    }

}
