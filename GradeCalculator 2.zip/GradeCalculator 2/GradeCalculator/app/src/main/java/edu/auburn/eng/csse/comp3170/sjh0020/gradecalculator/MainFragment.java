package edu.auburn.eng.csse.comp3170.sjh0020.gradecalculator;

import android.content.Context;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v4.app.FragmentTransaction;
import android.widget.Toast;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * {@link MainFragment.OnFragmentInteractionListener} interface
 * to handle interaction events.
 * Use the {@link MainFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class MainFragment extends Fragment {
    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER

    // TODO: Rename and change types of parameters

    private OnFragmentInteractionListener mListener;


    Button button;
    public MainFragment() {
        // Required empty public constructor
    }

    // TODO: Rename and change types and number of parameters
    public static MainFragment newInstance() {
        MainFragment fragment = new MainFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.activity_main, container, false);


    }

    @Override
    public void onStart(){
        super.onStart();

        TextView class1 = (TextView) getView().findViewById(R.id.class1);
        TextView class2 = (TextView) getView().findViewById(R.id.class2);
        TextView class3 = (TextView) getView().findViewById(R.id.class3);
        TextView class4 = (TextView) getView().findViewById(R.id.class4);
        TextView class5 = (TextView) getView().findViewById(R.id.class5);
        TextView class6 = (TextView) getView().findViewById(R.id.class6);
        TextView class7 = (TextView) getView().findViewById(R.id.class7);
        int numberOfCourses = MainActivity.courses.size();

        class1.setVisibility(View.INVISIBLE);
        class2.setVisibility(View.INVISIBLE);
        class3.setVisibility(View.INVISIBLE);
        class4.setVisibility(View.INVISIBLE);
        class5.setVisibility(View.INVISIBLE);
        class6.setVisibility(View.INVISIBLE);
        class7.setVisibility(View.INVISIBLE);
        switch(numberOfCourses){
            case 7:
                class7.setVisibility(View.VISIBLE);
            case 6:
                class6.setVisibility(View.VISIBLE);
            case 5:
                class5.setVisibility(View.VISIBLE);
            case 4:
                class4.setVisibility(View.VISIBLE);
            case 3:
                class3.setVisibility(View.VISIBLE);
            case 2:
                class2.setVisibility(View.VISIBLE);
            case 1:
                class1.setVisibility(View.VISIBLE);
            default:
                break;
        }


    }




    public interface OnFragmentInteractionListener {
        void onFragmentInteraction(Uri uri);
    }

    /*public void onCalculatePressed(View v) {

        System.out.println("calculating Grade");
        double totalGrade = 0.0;

        EditText weightField;
        EditText gradeField;
        double weight = 0.0;
        double grade = 0.0;

        try {
            weightField = (EditText) getView().findViewById(R.id.weight1);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) getView().findViewById((R.id.grade1));
            grade = Double.parseDouble(gradeField.getText().toString());
        }
        catch(Exception e){
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        try {
            weightField = (EditText) getView().findViewById(R.id.weight2);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) getView().findViewById((R.id.grade2));
            grade = Double.parseDouble(gradeField.getText().toString());
        }
        catch(Exception e){
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        try {
            weightField = (EditText) getView().findViewById(R.id.weight3);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) getView().findViewById((R.id.grade3));
            grade = Double.parseDouble(gradeField.getText().toString());
        }
        catch(Exception e){
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        try {
            weightField = (EditText) getView().findViewById(R.id.weight4);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) getView().findViewById((R.id.grade4));
            grade = Double.parseDouble(gradeField.getText().toString());
        }
        catch(Exception e){
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;


        try {
            weightField = (EditText) getView().findViewById(R.id.weight5);
            weight = Double.parseDouble(weightField.getText().toString());
            gradeField = (EditText) getView().findViewById((R.id.grade5));
            grade = Double.parseDouble(gradeField.getText().toString());
        }
        catch(Exception e){
            weight = 0.0;
            grade = 0.0;
        }
        totalGrade += weight * grade;

        TextView totalGradeView;
        totalGradeView = (TextView) getView().findViewById(R.id.finalGrade);
        totalGradeView.setText(Double.toString(totalGrade));


        Toast.makeText(getActivity(), Double.toString(totalGrade), Toast.LENGTH_SHORT).show();


    }*/
}
